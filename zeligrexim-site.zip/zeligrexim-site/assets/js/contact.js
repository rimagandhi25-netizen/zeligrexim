/* Zeligr Exim — enquiry form. No server needed: sends via WhatsApp or the visitor's email app. */
(function () {
  'use strict';
  var form = document.querySelector('[data-enquiry]');
  if (!form) return;
  var WA = form.getAttribute('data-wa');
  var MAIL = form.getAttribute('data-mail');
  var msg = form.querySelector('.form-msg');

  function compose() {
    var f = form.elements;
    var lines = [
      'Enquiry from zeligrexim.com',
      'Name: ' + f.name.value.trim(),
      f.company.value.trim() ? 'Company: ' + f.company.value.trim() : '',
      'Phone: ' + f.phone.value.trim(),
      f.email.value.trim() ? 'Email: ' + f.email.value.trim() : '',
      'Interested in: ' + f.interest.value,
      f.qty.value.trim() ? 'Quantity: ' + f.qty.value.trim() : '',
      '',
      f.message.value.trim()
    ];
    return lines.filter(function (l, i) { return l !== '' || i === 7; }).join('\n');
  }
  function valid() {
    var f = form.elements;
    if (!f.name.value.trim()) return 'Add your name so we know who to reply to.';
    if (!/^[+\d][\d\s-]{6,}$/.test(f.phone.value.trim())) return 'Add a phone number with country code, for example +91 98765 43210.';
    if (f.email.value.trim() && !/^\S+@\S+\.\S+$/.test(f.email.value.trim())) return 'Check the email address format.';
    return '';
  }
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var via = (e.submitter && e.submitter.value) || 'wa';
    var err = valid();
    if (err) { msg.textContent = err; msg.style.color = 'var(--accent)'; return; }
    var text = compose();
    msg.style.color = '';
    if (via === 'mail') {
      msg.textContent = 'Opening your email app with the enquiry filled in.';
      location.href = 'mailto:' + MAIL + '?subject=' + encodeURIComponent('Raw cashew enquiry: ' + form.elements.name.value.trim()) + '&body=' + encodeURIComponent(text);
    } else {
      msg.textContent = 'Opening WhatsApp with the enquiry filled in.';
      window.open('https://wa.me/' + WA + '?text=' + encodeURIComponent(text), '_blank', 'noopener');
    }
  });
})();
