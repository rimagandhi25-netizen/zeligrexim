/* Zeligr Exim — site motion + interactions */
(function () {
  'use strict';
  var d = document, html = d.documentElement, w = window;
  var RM = w.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var G = w.gsap;
  var MOTION = !RM && !!G;
  var FINE = w.matchMedia('(pointer:fine)').matches;
  w.__zxReady = true;
  if (!MOTION) html.classList.remove('motion', 'intro-pending', 'curtain-in');

  var ZX = w.ZX = { motion: MOTION, lenis: null };

  if (G) {
    var plugins = [w.ScrollTrigger, w.SplitText, w.Flip, w.DrawSVGPlugin].filter(Boolean);
    G.registerPlugin.apply(G, plugins);
  }

  /* ---------- Theme ---------- */
  function currentTheme() {
    var t = html.getAttribute('data-theme');
    if (t) return t;
    return w.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  d.querySelectorAll('.theme-btn').forEach(function (b) {
    b.addEventListener('click', function () {
      var next = currentTheme() === 'dark' ? 'light' : 'dark';
      var apply = function () {
        html.setAttribute('data-theme', next);
        try { localStorage.setItem('zx-theme', next); } catch (e) {}
        w.dispatchEvent(new CustomEvent('zx:theme', { detail: next }));
      };
      if (d.startViewTransition && MOTION) {
        var r = b.getBoundingClientRect();
        html.style.setProperty('--vt-x', (r.left + r.width / 2) + 'px');
        html.style.setProperty('--vt-y', (r.top + r.height / 2) + 'px');
        d.startViewTransition(apply);
      } else apply();
    });
  });

  /* ---------- Smooth scroll ---------- */
  if (false && MOTION && w.Lenis) { // rev2: native scrolling
    var lenis = ZX.lenis = new w.Lenis({ lerp: 0.1, smoothWheel: true });
    lenis.on('scroll', w.ScrollTrigger.update);
    G.ticker.add(function (t) { lenis.raf(t * 1000); });
    G.ticker.lagSmoothing(0);
  }
  function scrollToEl(el) {
    var off = -(parseInt(getComputedStyle(html).getPropertyValue('--header-h')) || 76) - 16;
    if (ZX.lenis) ZX.lenis.scrollTo(el, { offset: off, duration: 1.2 });
    else el.scrollIntoView({ behavior: RM ? 'auto' : 'smooth' });
  }
  d.addEventListener('click', function (e) {
    var a = e.target.closest('a[href^="#"]');
    if (!a) return;
    var id = a.getAttribute('href').slice(1);
    var t = id && d.getElementById(id);
    if (t) { e.preventDefault(); scrollToEl(t); history.replaceState(null, '', '#' + id); }
  });

  /* ---------- Header ---------- */
  var hdr = d.querySelector('.hdr');
  var lastY = 0;
  function onScroll() {
    var y = w.scrollY;
    if (hdr) {
      hdr.classList.toggle('is-scrolled', y > 20);
      var menuOpen = d.querySelector('.mnav.is-open');
      if (!menuOpen) hdr.classList.toggle('is-hidden', y > 320 && y > lastY + 2);
      if (y < lastY - 2) hdr.classList.remove('is-hidden');
    }
    lastY = y;
  }
  w.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- Mobile menu ---------- */
  var mnav = d.querySelector('.mnav');
  var mBtn = d.querySelector('.menu-btn');
  function setMenu(open) {
    if (!mnav) return;
    mnav.classList.toggle('is-open', open);
    mnav.setAttribute('aria-hidden', String(!open));
    if (mBtn) mBtn.setAttribute('aria-expanded', String(open));
    if (ZX.lenis) open ? ZX.lenis.stop() : ZX.lenis.start();
    d.body.style.overflow = open ? 'hidden' : '';
    if (open) {
      var links = mnav.querySelectorAll('nav a');
      if (MOTION) G.fromTo(links, { yPercent: 100, opacity: 0 }, { yPercent: 0, opacity: 1, stagger: 0.05, duration: 0.8, ease: 'expo.out', delay: 0.15 });
      setTimeout(function () { var c = mnav.querySelector('.mnav__close'); c && c.focus(); }, 50);
    } else if (mBtn) mBtn.focus();
  }
  if (mBtn) mBtn.addEventListener('click', function () { setMenu(true); });
  if (mnav) {
    mnav.querySelector('.mnav__close').addEventListener('click', function () { setMenu(false); });
    d.addEventListener('keydown', function (e) { if (e.key === 'Escape' && mnav.classList.contains('is-open')) setMenu(false); });
  }

  /* ---------- Page curtain (between pages) ---------- */
  var curtain = d.querySelector('.curtain');
  try { sessionStorage.removeItem('zx-curtain'); } catch (e) {}
  if (MOTION && curtain && html.classList.contains('curtain-in')) {
    G.to(curtain, {
      yPercent: -101, duration: 0.75, ease: 'power3.inOut', delay: 0.05,
      onComplete: function () { html.classList.remove('curtain-in'); G.set(curtain, { clearProps: 'all' }); }
    });
  }
  w.addEventListener('pageshow', function (e) {
    if (e.persisted && curtain) { html.classList.remove('curtain-in'); G && G.set(curtain, { clearProps: 'all' }); }
  });
  if (MOTION && curtain) {
    d.addEventListener('click', function (e) {
      var a = e.target.closest('a[href]');
      if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
      if (a.target && a.target !== '_self') return;
      if (a.hasAttribute('download') || a.dataset.noCurtain !== undefined) return;
      var url;
      try { url = new URL(a.href, location.href); } catch (er) { return; }
      if (url.origin !== location.origin || !/^https?:$/.test(url.protocol)) return;
      if (url.pathname === location.pathname && url.hash) return;
      if (/\.(pdf|jpe?g|png|webp|zip)$/i.test(url.pathname)) return;
      e.preventDefault();
      try { sessionStorage.setItem('zx-curtain', '1'); } catch (er) {}
      if (mnav && mnav.classList.contains('is-open')) mnav.classList.remove('is-open');
      G.fromTo(curtain, { yPercent: 101 }, { yPercent: 0, duration: 0.55, ease: 'power3.inOut', onComplete: function () { location.href = url.href; } });
    });
  }

  /* ---------- Logo intro (first page of a session) ---------- */
  function runIntro() {
    var el = d.querySelector('.intro');
    if (!MOTION || !el || !html.classList.contains('intro-pending')) {
      html.classList.remove('intro-pending');
      return Promise.resolve();
    }
    try { sessionStorage.setItem('zx-intro', '1'); } catch (e) {}
    return new Promise(function (resolve) {
      var svg = el.querySelector('svg');
      var word = svg.querySelector('.p-word'), exim = svg.querySelector('.p-exim'),
          tag = svg.querySelector('.p-tag'), disc = svg.querySelector('.p-disc'), cash = svg.querySelector('.p-cash');
      var hLogo = d.querySelector('.hdr__logo svg');
      if (hLogo) G.set(hLogo, { opacity: 0 });
      G.set([word, cash], { fillOpacity: 0 });
      G.set(word, { stroke: getComputedStyle(svg).getPropertyValue('--logo-ink') || '#0069AF', strokeWidth: 1.1 });
      G.set(cash, { stroke: '#fff', strokeWidth: 1 });
      var done = false;
      var finish = function () {
        if (done) return; done = true;
        var t = hLogo ? hLogo.getBoundingClientRect() : null;
        var s = svg.getBoundingClientRect();
        var out = G.timeline({
          onComplete: function () {
            html.classList.remove('intro-pending');
            el.remove();
            if (hLogo) G.set(hLogo, { opacity: 1 });
          }
        });
        if (t && t.width) {
          out.to(svg, { x: t.left - s.left, y: t.top - s.top, scale: t.width / s.width, transformOrigin: '0 0', duration: 0.9, ease: 'expo.inOut' }, 0);
        } else out.to(svg, { opacity: 0, duration: 0.4 }, 0);
        var bgc = getComputedStyle(el).backgroundColor.replace(/rgba?\(([^)]+)\)/, function (m, c) { return 'rgba(' + c.split(',').slice(0, 3).join(',') + ',0)'; });
        out.to(el, { backgroundColor: bgc, duration: 0.6, ease: 'power2.inOut' }, 0.15);
        out.to(el.querySelector('.intro__skip'), { opacity: 0, duration: 0.2 }, 0);
        setTimeout(resolve, 380);
      };
      var tl = G.timeline({ delay: 0.15, onComplete: finish });
      tl.fromTo(word, { drawSVG: '0%' }, { drawSVG: '100%', duration: 1.25, ease: 'power2.inOut' }, 0)
        .to(word, { fillOpacity: 1, duration: 0.5, ease: 'power1.out' }, 1.0)
        .to(word, { strokeOpacity: 0, duration: 0.4 }, 1.2)
        .from(disc, { scale: 0, transformOrigin: '50% 50%', duration: 0.85, ease: 'back.out(2.2)' }, 0.5)
        .fromTo(cash, { drawSVG: '0%' }, { drawSVG: '100%', duration: 0.7, ease: 'power2.inOut' }, 0.9)
        .to(cash, { fillOpacity: 1, strokeOpacity: 0, duration: 0.35 }, 1.45)
        .from(exim, { y: 26, opacity: 0, duration: 0.7, ease: 'expo.out' }, 1.15)
        .from(tag, { y: 14, opacity: 0, duration: 0.7, ease: 'expo.out' }, 1.35)
        .to({}, { duration: 0.25 });
      var skip = function () { tl.progress(1); };
      el.addEventListener('click', skip);
      d.addEventListener('keydown', function k(e) { if (e.key === 'Escape' || e.key === 'Enter') { skip(); d.removeEventListener('keydown', k); } });
    });
  }

  /* ---------- Reveals ---------- */
  function splitHeading(el, play) {
    G.set(el, { visibility: 'visible' });
    var cfg = { opacity: 0, y: 22, duration: 1, ease: 'power3.out' };
    if (play === 'manual') {
      G.set(el, { opacity: 0, y: 22 });
      el._splitPlay = function () { G.to(el, { opacity: 1, y: 0, duration: 1.1, ease: 'power3.out' }); };
      return;
    }
    cfg.scrollTrigger = { trigger: el, start: 'top 90%', once: true };
    G.from(el, cfg);
  }

  function initReveals() {
    if (!MOTION) return;
    var ST = w.ScrollTrigger;

    d.querySelectorAll('[data-split]').forEach(function (el) {
      splitHeading(el, el.getAttribute('data-split') === 'hero' ? 'manual' : 'scroll');
    });

    ST.batch('[data-fade]', {
      start: 'top 90%', once: true,
      onEnter: function (b) { G.to(b, { opacity: 1, y: 0, duration: 1.05, stagger: 0.08, ease: 'expo.out', overwrite: true }); }
    });

    d.querySelectorAll('.ph').forEach(function (ph) {
      if (ph.closest('.hs') && w.innerWidth > 900) return; // handled by horizontal scroller
      var inner = ph.querySelector('.ph__in');
      if (!inner) return;
      ST.create({
        trigger: ph, start: 'top 88%', once: true,
        onEnter: function () {
          G.to(inner, { opacity: 1, y: 0, duration: 1.1, ease: 'power3.out' });
          setTimeout(function () { ph.classList.add('is-in'); }, 650);
        }
      });
      if (ph.hasAttribute('data-parallax')) {
        /* rev2: no parallax */
      }
    });

    d.querySelectorAll('[data-count]').forEach(function (el) {
      var to = parseFloat(el.getAttribute('data-count'));
      var o = { v: 0 };
      el.textContent = '0';
      ST.create({
        trigger: el, start: 'top 90%', once: true,
        onEnter: function () { G.to(o, { v: to, duration: 2.2, ease: 'power3.out', onUpdate: function () { el.textContent = Math.round(o.v).toLocaleString('en-IN'); } }); }
      });
    });

    d.querySelectorAll('[data-words-off]').forEach(function (el) {
      if (!w.SplitText) return;
      var s = w.SplitText.create(el, { type: 'words' });
      G.fromTo(s.words, { opacity: 0.13 }, { opacity: 1, stagger: 0.1, ease: 'none', scrollTrigger: { trigger: el, start: 'top 82%', end: 'bottom 45%', scrub: true } });
    });

    d.querySelectorAll('[data-draw]').forEach(function (el) {
      if (!w.DrawSVGPlugin) return;
      G.fromTo(el, { drawSVG: '0%' }, { drawSVG: '100%', duration: 1.8, ease: 'power2.inOut', scrollTrigger: { trigger: el.closest('svg') || el, start: 'top 80%', once: true } });
    });

    d.querySelectorAll('[data-pop]').forEach(function (el) {
      G.from(el.children, { scale: 0, transformOrigin: '50% 50%', duration: 0.8, stagger: 0.12, ease: 'back.out(2)', scrollTrigger: { trigger: el, start: 'top 80%', once: true } });
    });

    d.querySelectorAll('[data-stagger]').forEach(function (el) {
      G.from(el.children, { opacity: 0, y: 30, duration: 0.9, stagger: 0.07, ease: 'expo.out', scrollTrigger: { trigger: el, start: 'top 85%', once: true } });
    });

    d.querySelectorAll('.season').forEach(function (t) {
      var bars = t.querySelectorAll('td.on');
      G.from(bars, { scaleX: 0, transformOrigin: '0 50%', duration: 0.6, stagger: { each: 0.008, from: 'start' }, ease: 'power2.out', scrollTrigger: { trigger: t, start: 'top 80%', once: true } });
    });

    // Marquee speeds up with scroll velocity
    var tracks = Array.prototype.slice.call(d.querySelectorAll('.marquee__track'));
    if (tracks.length && tracks[0].getAnimations) {
      var rate = { v: 1 };
      ST.create({ onUpdate: function (self) {
        var v = Math.min(Math.abs(self.getVelocity()) / 350, 5);
        rate.v = Math.max(rate.v, 1 + v);
      } });
      G.ticker.add(function () {
        rate.v += (1 - rate.v) * 0.06;
        tracks.forEach(function (t) { t.getAnimations().forEach(function (a) { a.playbackRate = rate.v; }); });
      });
    }

    // Horizontal pinned process
    var mm = G.matchMedia();
    mm.add('(min-width: 901px)', function () {
      d.querySelectorAll('.hs').forEach(function (sec) {
        var track = sec.querySelector('.hs__track');
        var bar = sec.querySelector('.hs__progress i');
        var dist = function () { return Math.max(0, track.scrollWidth - w.innerWidth); };
        var tw = G.to(track, {
          x: function () { return -dist(); }, ease: 'none',
          scrollTrigger: {
            trigger: sec, start: 'top top', end: function () { return '+=' + dist(); }, pin: true, scrub: 0.8, invalidateOnRefresh: true,
            onUpdate: function (self) { if (bar) G.set(bar, { scaleX: self.progress }); }
          }
        });
        sec.querySelectorAll('.ph').forEach(function (ph) {
          var inner = ph.querySelector('.ph__in');
          G.set(inner, { clipPath: 'inset(0% 0 0 0)' });
          w.ScrollTrigger.create({ trigger: ph, containerAnimation: tw, start: 'left 78%', onEnter: function () { ph.classList.add('is-in'); } });
        });
      });
    });

    // Footer wordmark
    var fw = null;
    if (fw && w.SplitText) {
      var fs = w.SplitText.create(fw, { type: 'chars', charsClass: 'fw-c' });
      G.from(fs.chars, { yPercent: 100, duration: 1, stagger: 0.04, ease: 'expo.out', scrollTrigger: { trigger: fw, start: 'top 95%', once: true } });
    }

    // Magnetic buttons
    if (false) {
      d.querySelectorAll('.btn--mag').forEach(function (b) {
        b.addEventListener('mousemove', function (e) {
          var r = b.getBoundingClientRect();
          G.to(b, { x: (e.clientX - r.left - r.width / 2) * 0.25, y: (e.clientY - r.top - r.height / 2) * 0.35, duration: 0.5, ease: 'power3.out' });
        });
        b.addEventListener('mouseleave', function () { G.to(b, { x: 0, y: 0, duration: 0.7, ease: 'elastic.out(1,.4)' }); });
      });
    }
  }

  /* ---------- Home hero entrance ---------- */
  function heroIn() {
    var hero = d.querySelector('.hero, .hero2');
    var h1 = d.querySelector('[data-split="hero"]');
    if (!MOTION) return;
    var tl = G.timeline();
    if (h1 && h1._splitPlay) tl.add(function () { h1._splitPlay(); }, 0);
    if (!hero) return;
    if (hero.classList.contains('hero2')) {
      tl.from(hero.querySelector('.hero2__bg img'), { scale: 1.12, duration: 2.4, ease: 'power2.out' }, 0)
        .from(hero.querySelectorAll('.eyebrow, .hero2__sub, .btn-row, .hero2__cue'), { opacity: 0, y: 24, duration: 1, stagger: 0.1, ease: 'power3.out' }, 0.3);
      return;
    }
    tl.from(hero.querySelectorAll('.eyebrow, .hero__sub, .hero .btn-row, .hero__facts'), { opacity: 0, y: 24, duration: 1, stagger: 0.1, ease: 'power3.out' }, 0.25)
      .from(hero.querySelector('.hero__main'), { opacity: 0, scale: 0.94, duration: 1.3, ease: 'power3.out' }, 0.1)
      .from(hero.querySelector('.hero__small'), { opacity: 0, y: 40, duration: 1.1, ease: 'power3.out' }, 0.5)
      .from(hero.querySelector('.hero__badge'), { opacity: 0, scale: 0.8, duration: 0.9, ease: 'back.out(1.8)' }, 0.8);
  }
  function pageHeadIn() {
    var ph = d.querySelector('.phead, .art-head, .net-hero');
    if (!ph || !MOTION) return;
    var h = ph.querySelector('[data-split="hero"]');
    if (h && h._splitPlay) h._splitPlay();
    G.from(ph.querySelectorAll('.crumbs, .lead, .phead__mark, .art-meta'), { opacity: 0, y: 24, duration: 1, stagger: 0.08, ease: 'expo.out', delay: 0.25 });
  }

  /* ---------- Lightbox / video modal ---------- */
  var lb, lbStage, lbCount, items = [], idx = 0, lastFocus;
  var ICON = {
    x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    l: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 5l-7 7 7 7"/></svg>',
    r: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 5l7 7-7 7"/></svg>'
  };
  function buildLB() {
    if (lb) return;
    lb = d.createElement('div');
    lb.className = 'lb';
    lb.setAttribute('role', 'dialog'); lb.setAttribute('aria-modal', 'true'); lb.setAttribute('aria-label', 'Media viewer');
    lb.innerHTML = '<div class="lb__bar"><span class="lb__title"></span><button class="icon-btn lb__close" aria-label="Close">' + ICON.x + '</button></div>' +
      '<div class="lb__stage"><button class="icon-btn lb__nav lb__nav--p" aria-label="Previous">' + ICON.l + '</button><div class="lb__media"></div><button class="icon-btn lb__nav lb__nav--n" aria-label="Next">' + ICON.r + '</button></div>' +
      '<div class="lb__count" aria-live="polite"></div>';
    d.body.appendChild(lb);
    lbStage = lb.querySelector('.lb__media'); lbCount = lb.querySelector('.lb__count');
    lb.querySelector('.lb__close').addEventListener('click', closeLB);
    lb.querySelector('.lb__nav--p').addEventListener('click', function () { go(-1); });
    lb.querySelector('.lb__nav--n').addEventListener('click', function () { go(1); });
    lb.addEventListener('click', function (e) { if (e.target === lb || e.target.classList.contains('lb__stage')) closeLB(); });
    d.addEventListener('keydown', function (e) {
      if (!lb.classList.contains('is-open')) return;
      if (e.key === 'Escape') closeLB();
      if (e.key === 'ArrowRight') go(1);
      if (e.key === 'ArrowLeft') go(-1);
      if (e.key === 'Tab') {
        var f = lb.querySelectorAll('button:not([hidden]), iframe');
        if (!f.length) return;
        var first = f[0], last = f[f.length - 1];
        if (e.shiftKey && d.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && d.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
    var sx = null;
    lb.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
    lb.addEventListener('touchend', function (e) { if (sx === null) return; var dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 50) go(dx < 0 ? 1 : -1); sx = null; });
  }
  function render() {
    var it = items[idx];
    lbStage.innerHTML = '';
    if (it.type === 'yt') {
      var f = d.createElement('iframe');
      f.src = 'https://www.youtube-nocookie.com/embed/' + it.id + '?autoplay=1&rel=0&playsinline=1';
      f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
      f.allowFullscreen = true;
      f.title = it.title || 'Video';
      if (it.short) f.className = 'is-short';
      lbStage.appendChild(f);
    } else {
      var im = new Image();
      im.src = it.src; im.alt = it.alt || '';
      lbStage.appendChild(im);
      if (MOTION) G.from(im, { opacity: 0, scale: 0.96, duration: 0.5, ease: 'expo.out' });
    }
    lb.querySelector('.lb__title').textContent = it.title || it.alt || '';
    var multi = items.length > 1;
    lb.querySelectorAll('.lb__nav').forEach(function (b) { b.hidden = !multi; });
    lbCount.textContent = multi ? (idx + 1) + ' / ' + items.length : '';
  }
  function go(n) { if (items.length < 2) return; idx = (idx + n + items.length) % items.length; render(); }
  function openLB(list, i) {
    buildLB(); items = list; idx = i || 0; lastFocus = d.activeElement;
    render(); lb.classList.add('is-open');
    if (ZX.lenis) ZX.lenis.stop();
    d.body.style.overflow = 'hidden';
    setTimeout(function () { lb.querySelector('.lb__close').focus(); }, 30);
  }
  function closeLB() {
    lb.classList.remove('is-open');
    setTimeout(function () { lbStage.innerHTML = ''; }, 350);
    if (ZX.lenis) ZX.lenis.start();
    d.body.style.overflow = '';
    if (lastFocus) lastFocus.focus();
  }
  ZX.openLightbox = openLB;
  d.addEventListener('click', function (e) {
    var b = e.target.closest('[data-yt]');
    if (!b || b.closest('.gal')) return;
    e.preventDefault();
    openLB([{ type: 'yt', id: b.getAttribute('data-yt'), short: b.hasAttribute('data-short'), title: b.getAttribute('data-title') }], 0);
  });

  /* ---------- Tabs ---------- */
  d.querySelectorAll('[role="tablist"]').forEach(function (list) {
    var tabs = list.querySelectorAll('[role="tab"]');
    tabs.forEach(function (t, i) {
      t.addEventListener('click', function () { select(i); });
      t.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowRight') { select((i + 1) % tabs.length); tabs[(i + 1) % tabs.length].focus(); }
        if (e.key === 'ArrowLeft') { select((i - 1 + tabs.length) % tabs.length); tabs[(i - 1 + tabs.length) % tabs.length].focus(); }
      });
    });
    function select(n) {
      tabs.forEach(function (t, i) {
        var on = i === n;
        t.setAttribute('aria-selected', String(on)); t.tabIndex = on ? 0 : -1;
        var p = d.getElementById(t.getAttribute('aria-controls'));
        if (p) {
          p.hidden = !on;
          if (on && MOTION) G.from(p, { opacity: 0, y: 16, duration: 0.6, ease: 'expo.out' });
        }
      });
    }
  });

  /* ---------- Harvest chart: current month ---------- */
  var M = new Date().getMonth();
  d.querySelectorAll('.season').forEach(function (t) {
    t.querySelectorAll('[data-m="' + M + '"]').forEach(function (c) { c.classList.add('cur'); if (c.classList.contains('on')) c.classList.add('now'); });
  });
  d.querySelectorAll('.mini').forEach(function (m) { var s = m.children[M]; if (s) s.classList.add('cur'); });
  d.querySelectorAll('[data-now-month]').forEach(function (el) {
    el.textContent = new Date().toLocaleString('en-GB', { month: 'long' });
  });

  /* ---------- Article: progress + TOC ---------- */
  var prog = d.querySelector('.progress');
  var art = d.querySelector('.prose');
  if (prog && art) {
    var upd = function () {
      var r = art.getBoundingClientRect();
      var p = Math.min(1, Math.max(0, -r.top / (r.height - w.innerHeight)));
      prog.style.transform = 'scaleX(' + p + ')';
    };
    w.addEventListener('scroll', upd, { passive: true }); upd();
    var tocLinks = d.querySelectorAll('.toc a');
    if (tocLinks.length && 'IntersectionObserver' in w) {
      var io = new IntersectionObserver(function (en) {
        en.forEach(function (x) {
          if (x.isIntersecting) tocLinks.forEach(function (a) { a.classList.toggle('is-active', a.getAttribute('href') === '#' + x.target.id); });
        });
      }, { rootMargin: '-20% 0px -70% 0px' });
      art.querySelectorAll('h2[id]').forEach(function (h) { io.observe(h); });
    }
  }

  /* ---------- Footer year ---------- */
  d.querySelectorAll('[data-year]').forEach(function (y) { y.textContent = new Date().getFullYear(); });

  /* ---------- Boot ---------- */
  function boot() {
    var fontsReady = d.fonts && d.fonts.ready ? d.fonts.ready : Promise.resolve();
    fontsReady.then(function () {
      initReveals();
      runIntro().then(function () { heroIn(); pageHeadIn(); });
      if (MOTION) setTimeout(function () { w.ScrollTrigger.refresh(); }, 600);
      w.dispatchEvent(new Event('zx:ready'));
    });
  }
  if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', boot); else boot();
})();
