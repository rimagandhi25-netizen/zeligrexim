/* Zeligr Exim — Network globe (d3-geo orthographic on canvas) */
(function () {
  'use strict';
  var d = document, w = window;
  var box = d.querySelector('.globe');
  if (!box || !w.d3) return;
  var DATA = JSON.parse(d.getElementById('origin-data').textContent);
  var ORIGINS = DATA.origins, PORTS = DATA.ports;
  var RM = w.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var canvas = box.querySelector('canvas');
  var ctx = canvas.getContext('2d');
  var tip = box.querySelector('.globe__tip');
  var dots = [];
  var month = new Date().getMonth();
  var focus = null;
  var rot = [-38, -8, 0];
  var dragging = false, visible = true, autoSpin = !RM;
  var size = 600, dpr = Math.min(w.devicePixelRatio || 1, 2);
  var proj = d3.geoOrthographic().clipAngle(90).precision(0.6);
  var path = d3.geoPath(proj, ctx);
  var colors = {};
  var t0 = performance.now();

  function readColors() {
    var cs = getComputedStyle(box);
    colors.fg = cs.getPropertyValue('--fg').trim() || '#000';
    colors.line = cs.getPropertyValue('--line').trim() || '#ddd';
    colors.muted = cs.getPropertyValue('--muted').trim() || '#777';
    colors.accent = cs.getPropertyValue('--accent').trim() || '#0069AF';
    colors.bg = cs.getPropertyValue('--bg').trim() || '#fff';
    colors.amber = '#F8A600';
  }
  readColors();
  w.addEventListener('zx:theme', function () { setTimeout(function () { readColors(); draw(); }, 30); });

  function resize() {
    var r = box.getBoundingClientRect();
    size = Math.max(260, Math.round(r.width));
    canvas.width = size * dpr; canvas.height = size * dpr;
    canvas.style.width = size + 'px'; canvas.style.height = size + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    proj.translate([size / 2, size / 2]).scale(size / 2 - 6);
    draw();
  }

  var portIdx = {};
  PORTS.forEach(function (p) { portIdx[p.name] = p; });
  function inSeason(o, m) { return o.months.indexOf(m) !== -1; }
  function visiblePt(lonlat) {
    var c = proj.invert([size / 2, size / 2]);
    return d3.geoDistance(lonlat, c) < Math.PI / 2 - 0.02;
  }

  function draw() {
    var now = performance.now();
    var t = (now - t0) / 1000;
    proj.rotate(rot);
    ctx.clearRect(0, 0, size, size);
    var R = proj.scale(), cx = size / 2, cy = size / 2;

    // sphere
    // outer glow
    var halo = ctx.createRadialGradient(cx, cy, R * 0.9, cx, cy, R * 1.08);
    halo.addColorStop(0, 'rgba(255,255,255,0.18)'); halo.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = halo; ctx.beginPath(); ctx.arc(cx, cy, R * 1.08, 0, Math.PI * 2); ctx.fill();
    // ocean: lit from top-left
    var grad = ctx.createRadialGradient(cx - R * 0.4, cy - R * 0.45, R * 0.05, cx, cy, R);
    grad.addColorStop(0, '#3B9BDB'); grad.addColorStop(0.55, '#1179BF'); grad.addColorStop(1, '#004F86');
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fillStyle = grad; ctx.fill();
    ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.stroke();

    // land dots
    var c = proj.invert([cx, cy]);
    ctx.fillStyle = '#ffffff';
    var ds = Math.max(1.4, size / 430);
    for (var i = 0; i < dots.length; i++) {
      var p = dots[i];
      var dist = d3.geoDistance(p, c);
      if (dist > 1.55) continue;
      var xy = proj(p);
      ctx.globalAlpha = 0.3 + 0.7 * Math.cos(dist);
      ctx.fillRect(xy[0] - ds / 2, xy[1] - ds / 2, ds, ds);
    }
    ctx.globalAlpha = 1;

    // arcs for in-season origins
    ORIGINS.forEach(function (o, k) {
      if (!o.port) return;
      var active = inSeason(o, month);
      if (!active && focus !== o) return;
      var to = portIdx[o.port];
      var line = { type: 'LineString', coordinates: [[o.lon, o.lat], [to.lon, to.lat]] };
      ctx.beginPath(); path(line);
      ctx.setLineDash([4, 5]); ctx.lineDashOffset = -t * 18;
      ctx.lineWidth = focus === o ? 2.4 : 1.4;
      ctx.strokeStyle = focus === o ? '#ffffff' : colors.amber;
      ctx.stroke(); ctx.setLineDash([]);
      // moving packet
      var interp = d3.geoInterpolate([o.lon, o.lat], [to.lon, to.lat]);
      var f = ((t * 0.18) + k * 0.13) % 1;
      var pt = interp(f);
      if (visiblePt(pt)) {
        var q = proj(pt);
        ctx.beginPath(); ctx.arc(q[0], q[1], 3.2, 0, Math.PI * 2); ctx.fillStyle = colors.amber; ctx.fill();
      }
    });

    // ports
    PORTS.forEach(function (p) {
      if (!visiblePt([p.lon, p.lat])) return;
      var q = proj([p.lon, p.lat]);
      ctx.fillStyle = '#ffffff';
      if (p.hq) {
        ctx.beginPath(); ctx.arc(q[0], q[1], 5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(q[0], q[1], 9 + Math.sin(t * 3) * 1.5, 0, Math.PI * 2);
        ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.2; ctx.stroke();
      } else {
        ctx.fillRect(q[0] - 3.5, q[1] - 3.5, 7, 7);
      }
    });

    // origins
    ORIGINS.forEach(function (o) {
      if (!visiblePt([o.lon, o.lat])) { o._xy = null; return; }
      var q = proj([o.lon, o.lat]); o._xy = q;
      var active = inSeason(o, month);
      if (active) {
        var pr = 6 + ((t * 0.9 + o.lon * 0.01) % 1) * 12;
        ctx.beginPath(); ctx.arc(q[0], q[1], pr, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(248,166,0,' + (1 - (pr - 6) / 12) * 0.8 + ')'; ctx.lineWidth = 1.4; ctx.stroke();
      }
      ctx.beginPath(); ctx.arc(q[0], q[1], active ? 5.5 : 3.6, 0, Math.PI * 2);
      ctx.fillStyle = active ? colors.amber : 'rgba(255,255,255,0.75)'; ctx.fill();
      if (active) { ctx.lineWidth = 1.5; ctx.strokeStyle = '#ffffff'; ctx.stroke(); }
      if (focus === o) {
        ctx.beginPath(); ctx.arc(q[0], q[1], 10, 0, Math.PI * 2);
        ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2; ctx.stroke();
        ctx.font = '700 15px Jakarta, "Segoe UI", sans-serif';
        ctx.fillStyle = '#ffffff'; ctx.textAlign = 'left';
        ctx.fillText(o.name, q[0] + 14, q[1] + 5);
      }
    });
  }

  function loop() {
    if (visible) {
      if (autoSpin && !dragging && !focusTween) rot[0] += 0.06;
      draw();
    }
    requestAnimationFrame(loop);
  }

  // Rotate to a point
  var focusTween = null;
  function rotateTo(o) {
    var target = [-o.lon, -o.lat * 0.8, 0];
    var from = rot.slice();
    var dl = ((target[0] - from[0] + 540) % 360) - 180;
    var start = performance.now(), dur = RM ? 1 : 1100;
    focusTween = true;
    (function step(now) {
      var k = Math.min(1, (now - start) / dur);
      var e = 1 - Math.pow(1 - k, 4);
      rot[0] = from[0] + dl * e;
      rot[1] = from[1] + (target[1] - from[1]) * e;
      if (k < 1) requestAnimationFrame(step); else focusTween = null;
    })(start);
  }

  // Interaction: drag
  var lastX, lastY;
  box.addEventListener('pointerdown', function (e) {
    dragging = true; lastX = e.clientX; lastY = e.clientY; box.setPointerCapture(e.pointerId);
  });
  box.addEventListener('pointermove', function (e) {
    var r = box.getBoundingClientRect();
    var mx = e.clientX - r.left, my = e.clientY - r.top;
    if (dragging) {
      var k = 180 / (proj.scale() * Math.PI);
      rot[0] += (e.clientX - lastX) * k;
      rot[1] = Math.max(-60, Math.min(60, rot[1] - (e.clientY - lastY) * k));
      lastX = e.clientX; lastY = e.clientY;
      autoSpin = false;
    }
    var hit = nearest(mx, my);
    if (hit && tip) {
      tip.textContent = hit.name + ': ' + hit.season;
      tip.style.left = hit._xy[0] + 'px'; tip.style.top = hit._xy[1] + 'px';
      tip.classList.add('on'); box.style.cursor = 'pointer';
    } else if (tip) { tip.classList.remove('on'); box.style.cursor = ''; }
  });
  box.addEventListener('pointerup', function (e) {
    var moved = Math.abs(e.clientX - lastX) + Math.abs(e.clientY - lastY);
    dragging = false;
    var r = box.getBoundingClientRect();
    var hit = nearest(e.clientX - r.left, e.clientY - r.top);
    if (hit) select(hit, false);
  });
  box.addEventListener('pointerleave', function () { if (tip) tip.classList.remove('on'); });
  function nearest(x, y) {
    var best = null, bd = 16;
    ORIGINS.forEach(function (o) {
      if (!o._xy) return;
      var dd = Math.hypot(o._xy[0] - x, o._xy[1] - y);
      if (dd < bd) { bd = dd; best = o; }
    });
    return best;
  }

  // Cards + chips
  var cards = d.querySelectorAll('.origin[data-origin]');
  var detail = d.querySelector('[data-origin-detail]');
  function select(o, scroll) {
    focus = o; autoSpin = false;
    rotateTo(o);
    cards.forEach(function (c) { c.classList.toggle('is-active', c.getAttribute('data-origin') === o.name); });
    d.querySelectorAll('.chip[data-origin]').forEach(function (c) { c.classList.toggle('is-active', c.getAttribute('data-origin') === o.name); });
    if (detail) {
      detail.innerHTML = '<b class="t-3">' + o.name + '</b><span class="muted"> harvest season: ' + o.season + '. ' +
        (o.port ? 'Illustrative route to ' + o.port + ' port.' : 'Domestic crop, traded locally within India.') + '</span>';
    }
    if (scroll) {
      var sec = d.querySelector('.net-hero');
      if (sec && w.ZX && w.ZX.lenis) w.ZX.lenis.scrollTo(sec, { offset: -60 });
      else if (sec) sec.scrollIntoView({ behavior: RM ? 'auto' : 'smooth' });
    }
  }
  cards.forEach(function (c) {
    c.addEventListener('click', function () {
      var o = ORIGINS.filter(function (x) { return x.name === c.getAttribute('data-origin'); })[0];
      if (o) select(o, true);
    });
  });

  var monthBtns = d.querySelectorAll('.months button');
  var nowList = d.querySelector('.now-list');
  var monthLabel = d.querySelector('[data-month-label]');
  var MN = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  function setMonth(m) {
    month = m;
    monthBtns.forEach(function (b, i) { b.setAttribute('aria-pressed', String(i === m)); });
    if (monthLabel) monthLabel.textContent = MN[m];
    var act = ORIGINS.filter(function (o) { return inSeason(o, m); });
    if (nowList) {
      nowList.innerHTML = act.length ? act.map(function (o) {
        return '<button type="button" class="chip" data-origin="' + o.name + '"><i></i>' + o.name + '</button>';
      }).join('') : '<span class="muted">No major harvest this month.</span>';
      nowList.querySelectorAll('.chip').forEach(function (c) {
        c.addEventListener('click', function () {
          var o = ORIGINS.filter(function (x) { return x.name === c.getAttribute('data-origin'); })[0];
          select(o, false);
        });
      });
      if (w.gsap && !RM) w.gsap.from(nowList.children, { opacity: 0, y: 10, stagger: 0.03, duration: 0.5, ease: 'expo.out' });
    }
    cards.forEach(function (c) {
      var o = ORIGINS.filter(function (x) { return x.name === c.getAttribute('data-origin'); })[0];
      c.classList.toggle('is-now', !!o && inSeason(o, m));
      c.querySelectorAll('.mini span').forEach(function (s, i) { s.classList.toggle('cur', i === m); });
    });
  }
  monthBtns.forEach(function (b, i) {
    if (i === new Date().getMonth()) b.classList.add('is-today');
    b.addEventListener('click', function () { setMonth(i); });
  });

  // Visibility pause
  if ('IntersectionObserver' in w) {
    new IntersectionObserver(function (en) { visible = en[0].isIntersecting; }).observe(box);
  }
  if ('ResizeObserver' in w) new ResizeObserver(resize).observe(box); else w.addEventListener('resize', resize);

  var src = box.getAttribute('data-dots');
  fetch(src).then(function (r) { return r.json(); }).then(function (j) {
    dots = j; resize(); setMonth(month);
    if (w.gsap && !RM) w.gsap.from(canvas, { opacity: 0, scale: 0.85, duration: 1.6, ease: 'expo.out' });
    requestAnimationFrame(loop);
  }).catch(function () { resize(); setMonth(month); requestAnimationFrame(loop); });
})();
