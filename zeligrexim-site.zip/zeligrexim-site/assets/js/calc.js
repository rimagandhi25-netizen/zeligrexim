/* Zeligr Exim — Raw cashew sample calculator
   Formula from the Zeligr Exim quality guide:
   Out-turn (lbs per 80 kg bag) = (good kernels g + 50% of half-rejected kernels g) x 0.176, per 1 kg sample. */
(function () {
  'use strict';
  var d = document, w = window;
  var form = d.querySelector('[data-calc]');
  if (!form) return;
  var out = {
    kor: d.querySelector('[data-o="kor"]'),
    grade: d.querySelector('[data-o="grade"]'),
    yield: d.querySelector('[data-o="yield"]'),
    nc: d.querySelector('[data-o="nc"]'),
    mo: d.querySelector('[data-o="mo"]'),
    def: d.querySelector('[data-o="def"]')
  };
  var shown = { v: 0 };

  function num(name) { var v = parseFloat(form.elements[name].value); return isFinite(v) ? v : 0; }
  function ncGrade(n) {
    if (!n) return '—';
    if (n < 180) return 'Excellent';
    if (n <= 190) return 'Very good';
    if (n <= 200) return 'Good';
    if (n <= 210) return 'Average';
    if (n <= 220) return 'Very average';
    if (n <= 230) return 'Just acceptable';
    return 'Poor';
  }
  function moisture(m) {
    if (!m) return '—';
    if (m < 6) return m + '%: too dry, brittle in processing';
    if (m <= 8) return m + '%: ideal range';
    if (m <= 10) return m + '%: acceptable, dry further';
    return m + '%: fungus risk';
  }
  function defects(p) {
    if (p === 0 && !form.elements.def.value) return '—';
    if (p <= 15) return p + '%: standard grade';
    if (p <= 24) return p + '%: under grade';
    return p + '%: rejected';
  }
  function korLabel(k) {
    if (!k) return 'Enter kernel weights';
    if (k >= 50) return 'High out-turn';
    if (k >= 48) return 'Within our spec (48–52 lbs)';
    if (k >= 45) return 'Below our spec';
    return 'Low out-turn';
  }
  function calc() {
    var kg = num('sample') || 1;
    var kor = ((num('good') + 0.5 * num('half')) * 0.176) / kg;
    kor = Math.round(kor * 100) / 100;
    var target = kor;
    if (w.gsap && !w.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      w.gsap.to(shown, { v: target, duration: 0.8, ease: 'power3.out', overwrite: true, onUpdate: function () { out.kor.firstChild.nodeValue = shown.v.toFixed(2); } });
    } else out.kor.firstChild.nodeValue = target.toFixed(2);
    out.grade.textContent = korLabel(kor);
    out.yield.textContent = kor ? (kor * 0.476).toFixed(2) + '%' : '—';
    out.nc.textContent = ncGrade(num('nc'));
    out.mo.textContent = moisture(num('moist'));
    out.def.textContent = defects(num('def'));
  }
  form.addEventListener('input', calc);
  form.addEventListener('submit', function (e) { e.preventDefault(); calc(); });
  calc();
})();
