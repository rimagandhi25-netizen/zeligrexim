/* Zeligr Exim — Gallery: filter (GSAP Flip) + lightbox */
(function () {
  'use strict';
  var d = document, w = window;
  var grid = d.querySelector('.gal');
  if (!grid) return;
  var RM = w.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var items = Array.prototype.slice.call(grid.querySelectorAll('.gal__item'));
  var btns = d.querySelectorAll('.gal-tabs button');
  var filter = 'all';

  function visibleItems() { return items.filter(function (i) { return !i.classList.contains('is-hidden'); }); }

  function apply(f) {
    filter = f;
    btns.forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-filter') === f)); });
    var state = (w.Flip && !RM) ? w.Flip.getState(items) : null;
    items.forEach(function (i) {
      var show = f === 'all' || i.getAttribute('data-type') === f;
      i.classList.toggle('is-hidden', !show);
    });
    if (state) {
      w.Flip.from(state, {
        duration: 0.8, ease: 'expo.inOut', absolute: true, scale: true, nested: true,
        onEnter: function (els) { return w.gsap.fromTo(els, { opacity: 0, scale: 0.8 }, { opacity: 1, scale: 1, duration: 0.7, ease: 'expo.out', stagger: 0.02 }); },
        onLeave: function (els) { return w.gsap.to(els, { opacity: 0, scale: 0.8, duration: 0.4 }); },
        onComplete: function () { if (w.ScrollTrigger) w.ScrollTrigger.refresh(); }
      });
    }
  }
  btns.forEach(function (b) { b.addEventListener('click', function () { apply(b.getAttribute('data-filter')); }); });

  grid.addEventListener('click', function (e) {
    var it = e.target.closest('.gal__item');
    if (!it || !w.ZX || !w.ZX.openLightbox) return;
    e.preventDefault();
    var vis = visibleItems();
    var list = vis.map(function (i) {
      var t = i.getAttribute('data-type');
      if (t === 'photo') return { type: 'img', src: i.getAttribute('data-full'), alt: i.querySelector('img').alt };
      return { type: 'yt', id: i.getAttribute('data-yt'), short: t === 'short', title: i.getAttribute('data-title') };
    });
    w.ZX.openLightbox(list, vis.indexOf(it));
  });

  // Colour-in on scroll + staggered entrance
  if (w.gsap && w.ScrollTrigger && !RM) {
    w.gsap.set(items, { opacity: 0 });
    w.ScrollTrigger.batch(items, {
      start: 'top 92%', once: true,
      onEnter: function (b) {
        w.gsap.fromTo(b, { opacity: 0, y: 40 }, { opacity: 1, y: 0, duration: 1, stagger: 0.06, ease: 'expo.out' });
        b.forEach(function (el, k) { setTimeout(function () { el.classList.add('is-in'); }, 500 + k * 60); });
      }
    });
  } else items.forEach(function (i) { i.classList.add('is-in'); });
})();
