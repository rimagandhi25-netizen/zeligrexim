/* Zeligr Exim — animated story reel (About page) */
(function () {
  'use strict';
  var reel = document.querySelector('[data-reel]');
  if (!reel) return;
  var RM = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var slides = reel.querySelectorAll('.reel__slide');
  var bars = reel.querySelectorAll('.reel__bar');
  var end = reel.querySelector('.reel__end');
  var pp = reel.querySelector('.reel__pp');
  var DUR = 4800, END_DUR = 3200;
  var i = 0, timer = null, playing = !RM, inView = false, t0 = 0, left = DUR;

  function show(n) {
    i = n;
    var isEnd = n >= slides.length;
    slides.forEach(function (s, k) { s.classList.toggle('is-on', k === n); });
    end.classList.toggle('is-on', isEnd);
    reel.classList.toggle('is-end', isEnd);
    bars.forEach(function (b, k) {
      b.classList.toggle('is-done', k < n);
      b.classList.toggle('is-on', k === n);
      b.setAttribute('aria-current', k === n ? 'true' : 'false');
    });
    reel.style.setProperty('--reel-dur', DUR + 'ms');
    restartBar();
    schedule(isEnd ? END_DUR : DUR);
  }
  function restartBar() {
    var cur = bars[i];
    if (!cur) return;
    var fill = cur.querySelector('i');
    fill.style.animation = 'none'; void fill.offsetWidth; fill.style.animation = '';
  }
  function schedule(ms) {
    clearTimeout(timer);
    left = ms; t0 = Date.now();
    if (playing && inView) timer = setTimeout(next, ms);
  }
  function next() { show(i >= slides.length ? 0 : i + 1); }
  function setPlaying(p) {
    playing = p;
    reel.classList.toggle('is-paused', !p);
    pp.setAttribute('aria-label', p ? 'Pause' : 'Play');
    if (p && inView) { t0 = Date.now(); timer = setTimeout(next, left); }
    else { clearTimeout(timer); left = Math.max(400, left - (Date.now() - t0)); }
  }
  pp.addEventListener('click', function () { setPlaying(!playing); });
  bars.forEach(function (b, k) { b.addEventListener('click', function () { show(k); }); });

  if ('IntersectionObserver' in window) {
    new IntersectionObserver(function (en) {
      var was = inView; inView = en[0].isIntersecting;
      reel.classList.toggle('is-visible', inView);
      if (inView && !was && playing) { t0 = Date.now(); timer = setTimeout(next, left); }
      if (!inView) { clearTimeout(timer); }
    }, { threshold: 0.35 }).observe(reel);
  } else inView = true;

  if (RM) { reel.classList.add('is-paused'); pp.setAttribute('aria-label', 'Play'); }
  show(0);
})();
