# Zeligr Exim website (static HTML5)

Plain HTML, CSS and JavaScript. No build step, no server, no database.

## Test it on your computer
Pages load data files, so open it through a local server, not by double-clicking `index.html`:

    cd zeligrexim-site
    python3 -m http.server 8000

Then visit http://localhost:8000

## Test it on GitHub
Push this folder as the root of a repository. For GitHub Pages: Settings > Pages > Deploy from branch > main / root.
Note: the 404 page uses root links (`/`), so it works fully on a custom domain or Cloudflare; on a `username.github.io/repo/` URL only that one page's links are affected.

## Go live on Cloudflare (later)
Cloudflare dashboard > Workers & Pages > Create > Pages > Upload assets > drag this folder > Deploy.
Then add zeligrexim.com under Custom domains. `_redirects` (old WordPress URLs) and `_headers` (caching) are read automatically.

## Where things are
- Pages: `index.html` and one folder per page (`about/`, `services/`, ...), same URLs as the old site
- Styles: `assets/css/main.css` (revision 2 theme block at the end: brand blue #0069AF, white, saffron #F8A600; fonts Plus Jakarta Sans + Nunito Sans)
- Motion: `assets/js/main.js`; globe: `network.js`; gallery: `gallery.js`; calculator: `calc.js`; enquiry form: `contact.js`
- Images: `assets/img/` (WebP plus JPG/PNG fallback). Logo: `assets/img/logo.svg`, `logo-white.svg`
- Libraries are bundled in `assets/vendor/` (GSAP 3.13, d3-geo), so nothing loads from outside except YouTube and Google Maps

## Common edits
- Phone / WhatsApp / email / address: search and replace `9726253214`, `zeligrexim@gmail.com` across the HTML files
- Swap a photo: replace the file in `assets/img/` with the same name (update both `.webp` and `.jpg`)
- The enquiry form opens WhatsApp or the visitor's email app with the message filled in; no form service needed
